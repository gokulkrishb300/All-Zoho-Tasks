package rotation;

import java.util.Arrays;

import input.InputCenter;

public class Rotation {
	
	
	private void reverse(int[] arr , int low , int high)
	{
		if(low < high) {
			
		while(arr[low]<arr[high])
		{
			int temp = arr[low];
			arr[low] = arr[high];
			arr[high] = temp;
			low++;
			high--;
		}
		}
	}
	
	private void rotate(int[] arr , int noOfElements , int rotation)
	{
		reverse(arr,rotation-1,noOfElements-1);
		reverse(arr,0,noOfElements-1);
		reverse(arr,0,rotation-1);
		
		System.out.println(Arrays.toString(arr));
	}
	
//	private void rotate(int[] arr , int noOfElements , int rotation) {
//		
//		int[] output = new int[noOfElements];
//		
//		int count = 0;
//		
//		for(int i = noOfElements-1 ; i >= 0 ; i--)
//		{
//			output[count++] = arr[i];
//		}
//		
//		for(int i = 0 ; i < rotation-1 ; i++)
//		{
//			output[count++] = arr[i];
//		}
//		System.out.println(Arrays.toString(output));
//	}

	
	
	public static void main(String[] args)
	{
		Rotation rotate = new Rotation();
		
		InputCenter input = new InputCenter();
		
		
		int arraySize = input.getInt("arraySize : ");
		
		int[] arr = new int[arraySize];
		
		for(int i = 0 ; i < arraySize ;i++)
		{
			arr[i] = input.getInt("");
		}
		int rotation = input.getInt("No.of rotation");
		
		rotate.rotate(arr,arraySize,rotation);
		
		System.out.println(Arrays.toString(arr));
	}
}
