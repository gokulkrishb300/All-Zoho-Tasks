package countchar;

import java.util.HashMap;
import java.util.Map;

import input.InputCenter;

public class CountChar {
	
	private String countChar(String input)
	{
		HashMap<Character,Integer> map = new HashMap<>();
		
		int count = 0;
		
		int length = input.length();
		
		for(int i = 0 ; i < length ; i++)
		{
			if(map.containsKey(input.charAt(i)))
			{
				map.put(input.charAt(i), map.get(input.charAt(i))+1);
			}
			else
			{
				count = 0;
				map.put(input.charAt(i), ++count);
			}
		}
		
		StringBuilder build = new StringBuilder();
		
		for(Map.Entry<Character, Integer> value : map.entrySet())
		{
			
			build.append(value.getKey()).append(value.getValue());
		}
		
		return build.toString();
	}
	
	public static void main(String[] args)
	
	{
		CountChar countChar = new CountChar();
		
		InputCenter input = new InputCenter();
		
		System.out.println(countChar.countChar(input.getString("input")));
	}
}
